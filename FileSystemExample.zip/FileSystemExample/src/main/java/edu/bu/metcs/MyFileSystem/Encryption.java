package edu.bu.metcs.MyFileSystem;

public interface Encryption {
    public String encrypt(String content);
}
