package edu.bu.metcs.MyFileSystem;

public interface Observer {
    public abstract void update();
}
