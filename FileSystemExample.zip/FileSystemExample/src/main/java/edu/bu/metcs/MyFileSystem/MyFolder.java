package edu.bu.metcs.MyFileSystem;

import java.util.ArrayList;
import java.util.List;

public class MyFolder extends MyFileComponent {
    private List<MyFileComponent> myChildren = new ArrayList<MyFileComponent>();

    public MyFolder(String name){
        setName(name);
        setOwner("root");
    }

    public void changeOwner(String newOwner){
        setOwner(newOwner);
        for (MyFileComponent myChild: myChildren)
            myChild.changeOwner(newOwner);
    }

    public List<MyFileComponent> getChildren() {return myChildren;}

    public void addChild(MyFileComponent aFileComposite){
        myChildren.add(aFileComposite);
    }

    public void delChild(MyFileComponent aFileComposite){
        myChildren.remove(aFileComposite);
    }
}
